abdo i added teacup sprites for each state. 
note that atk start for both states will be the same bcz am lazy.


By default the sprites are 64x64 unless indicated otherwise with the size written in the name. Each zip file contains animated frames for the given state which is open for change.

Also the frames may not only be used for the particular state for example dir atk has 5 frames but under 60fps it wont be seen at all so we can play these frames over the entirety of the attack phase hence why i didn't draw recovery phases.


